
package polimorfismo;

public class Polimorfismo {

    public static void main(String[] args) {
        
        //Pessoa p1 = new Pessoa();
        Funcionario f = new Funcionario("Maria", 1000.00, 100.00);
        
        System.out.println("Resultado: "+f.toString());
        
        Gerente g = new Gerente("Pedro", 1000.00, 100.00,1000.00);
        
        System.out.println("Resultado: "+g.toString());
    }
    
}
