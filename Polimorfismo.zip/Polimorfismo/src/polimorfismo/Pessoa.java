
package polimorfismo;

public abstract class Pessoa {
    private String nome;
    private double salario;
    //metodo construtor
    public Pessoa(String nome, double salario){
        this.nome = nome;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    //assinatura do metodo abstrato
    public abstract double calculaSalario();
    //não tem implementação
    
    @Override
    public String toString(){
        return String.format("\nNome: "+ getNome()
                +"\nSalario Padrao: "+ getSalario());   
    }
    
}
