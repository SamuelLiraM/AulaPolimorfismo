
package polimorfismo;

public class Funcionario extends Pessoa{
    private double salarioFamilia;

    public Funcionario(String nome, double salario, double salarioFamilia) {
        super(nome, salario);
        this.salarioFamilia = salarioFamilia;
    }
    
    @Override
    public double calculaSalario() {
       return super.getSalario()+getSalarioFamilia();
    }

    public double getSalarioFamilia() {
        return salarioFamilia;
    }

    public void setSalarioFamilia(double salarioFamilia) {
        this.salarioFamilia = salarioFamilia;
    }
    
    public String toString(){
        return String.format("" +super.toString()
        +"\nSalario Funcionario: "+calculaSalario());
    }
}
